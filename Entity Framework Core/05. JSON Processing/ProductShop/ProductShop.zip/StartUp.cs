﻿namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
        }
    }
}